export default async function UserPost() {
	return <div>유저 포스트</div>;
}
