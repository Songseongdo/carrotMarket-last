export default function UserLikes() {
	return <div>유저 라이크 모음</div>;
}
