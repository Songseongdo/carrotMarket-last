export default function UserReplies() {
	return <div>유저 댓글 모음</div>;
}
