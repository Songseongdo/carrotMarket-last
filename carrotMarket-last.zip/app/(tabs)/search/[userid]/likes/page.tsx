export default function SearchLikes() {
	return <div>검색 라이크 모음</div>;
}
