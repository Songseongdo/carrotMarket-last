export default function SearchPosts() {
	return <div>검색된 포스트</div>;
}
