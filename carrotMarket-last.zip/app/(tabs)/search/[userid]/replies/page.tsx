export default function SearchReplies() {
	return <div>검색 유저 댓글 모음</div>;
}
